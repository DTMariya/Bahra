# Weighbridge agent — deployment folder

Everything needed to run the agent on the Bahra dev server (`C:\weighbridge`).

> **`weighbridge-agent.config.json` contains the app registration's client secret.** Do not mail
> this folder around or commit it. The secret expires — put its expiry date and a named owner in
> the handover, because when it lapses rows stop arriving with no other warning.

## Files

| File | What it is |
|---|---|
| `Start-WeighbridgeAgent.ps1` | The agent. Watches the terminals, writes settled weights straight into Dataverse. |
| `weighbridge-agent.config.json` | Terminals, Dataverse credentials, column names, timings. The only file you normally edit. |
| `Install-WeighbridgeTask.ps1` | Registers the agent as a permanent scheduled task (boot start, auto-restart). |
| `Test-WeighbridgeAgent.ps1` | Health check. Exit code 0 healthy, 1 degraded, 2 down. |
| `Watch-OutStreams.ps1` | Live view of port 8000 on both OUT terminals. Read-only, for troubleshooting. |

## Install

1. Copy the whole folder's contents to `C:\weighbridge` on the dev server.
2. Open an **Administrator** PowerShell.
3. Run:

```powershell
& 'C:\weighbridge\Install-WeighbridgeTask.ps1'
```

It removes the old `WeighbridgeAgent-24h` task if present, registers `WeighbridgeAgent`, starts
it, and prints the health check. You want `state Running` and `HEALTHY`.

Start the agent with `& '...'`, never `powershell -File`: on this server `-File` leaves
`$PSScriptRoot` empty in the script's parameter defaults and the agent dies with
"No config at \weighbridge-agent.config.json". The installer already does this correctly.

## Day to day

```powershell
Get-ScheduledTask -TaskName 'WeighbridgeAgent' | Select-Object State      # Running
cd C:\weighbridge; .\Test-WeighbridgeAgent.ps1                            # HEALTHY / DEGRADED / DOWN
Get-Content C:\weighbridge\task-console.log -Tail 30                      # latest activity
Select-String -Path C:\weighbridge\logs\agent-*.log -Pattern 'CAPTURED|CORRECTION|posted HTTP'
```

`logs\agent-YYYY-MM-DD.log` is one file per day, kept 30 days. `task-console.log` is the same
output captured from the task and **grows forever** — clear it occasionally.

## Updating the agent

The watchdog restarts the task within 10 minutes, so disable it first:

```powershell
Disable-ScheduledTask -TaskName 'WeighbridgeAgent'
Stop-ScheduledTask    -TaskName 'WeighbridgeAgent'
# copy the new files into C:\weighbridge
Enable-ScheduledTask  -TaskName 'WeighbridgeAgent'
Start-ScheduledTask   -TaskName 'WeighbridgeAgent'
```

## What it sends

One truck normally produces **two rows**, both plain creates:

| `sequence` | `reason` | |
|---|---|---|
| 1 | `settled` | the weight once the truck has stood still for `settleSeconds` — usually with the driver still in the cab |
| 2 | `driver-out` | the corrected weight after the driver climbs down. **This is the number the gate office writes down.** |

Others: `part-way-on` if the truck was only partly on the deck at the first post, and `back-on`
when someone climbs back in — filed too, since `sendEverySettledWeight` is now true.

**Timestamps come from this server's own clock and Windows time zone.** Set the server's time zone
correctly and keep it on NTP: the clock is now part of the data, and if it drifts every row drifts
with it.

**Every reading is inserted; nothing is updated in place.** The table has no `sequence` column, so
whatever reads it cannot tell a correction from a fresh weighing except by time. Take the **latest
row for that terminal**, never the first — the earlier row carries the driver's weight as well as
the load.

## Settings worth knowing

| Setting | Now | Meaning |
|---|---|---|
| `settleSeconds` | 8 | How long the weight must hold before the first post. Raise it if `part-way-on` corrections are frequent. |
| `settleTolerance` | 200 | Readings this far apart still count as the same weight. |
| `updateSteadySeconds` | 5 | How long a new weight must hold before a correction is sent. |
| `changeThreshold` | 20 | A change smaller than this is ignored. One scale division; a driver is around 80 kg. |
| `majorIncreaseKg` | 500 | A rise must exceed this to be sent, so the driver climbing back in is ignored. |
| `maxUpdatesPerTruck` | 0 | Cap on corrections per truck. **0 = no cap.** |
| `sendEverySettledWeight` | true | Files every settled weight, `back-on` included, tagged in `reason`. The last row is then not necessarily the right one. |
| `stuckCapturedMinutes` | 30 | Alarm when a deck never clears. Raise it if trucks routinely stand longer. |

## Terminals

| Address | Terminal |
|---|---|
| 192.168.104.51 | JV Scale **OUT** |
| 192.168.104.52 | JV Scale **IN** |
| 192.168.174.12 | South Gate OUT |
| 192.168.174.13 | South Gate **IN** — added 2026-09-28, never yet proven to answer |

The JV pair was the wrong way round until 2026-09-16; readings posted before that carry the
opposite direction.

South Gate IN was listed as `192.168.174.11` in Bahra's own email, and every probe of it used that
address — including the 2026-09-10 scan that found both ports closed and concluded the terminal was
dead. Bahra gave the real address as `192.168.174.13` on 2026-09-28, so **that conclusion never
tested this terminal at all.** It is now in the config. If `.13` does not answer, the log shows

```
South Gate IN: 8000 unreachable (...), retry in 60s [attempt N]
```

for that terminal only — the other three keep running. Delete its line from `terminals` to silence
it. To check before deploying:

```powershell
Test-NetConnection 192.168.174.13 -Port 1701
Test-NetConnection 192.168.174.13 -Port 8000
```
