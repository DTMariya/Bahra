<#
.SYNOPSIS
    Installs the weighbridge agent as a permanent scheduled task on this machine.

.DESCRIPTION
    Registers a task that:
      - starts at boot, as SYSTEM, before anyone logs in
      - never times out (Windows stops a task after 3 days by default)
      - is restarted within 10 minutes if it ever dies, by a repeating trigger with
        MultipleInstances = IgnoreNew, which does nothing while the agent is already running

    Run this from an ELEVATED PowerShell, on the machine that can reach the terminals.

    The agent is started with -Command "& '...'", never with -File. On the Bahra dev server
    -File leaves $PSScriptRoot empty in the script's parameter defaults, and the agent dies
    with "No config at \weighbridge-agent.config.json". -ConfigPath is passed for the same
    reason.

.EXAMPLE
    .\Install-WeighbridgeTask.ps1

.EXAMPLE
    # Register it but do not start it yet
    .\Install-WeighbridgeTask.ps1 -NoStart
#>
[CmdletBinding()]
param(
    # Where the agent lives on this machine. The files in this folder go here.
    [string]$Dir = 'C:\weighbridge',

    [string]$TaskName = 'WeighbridgeAgent',

    # Also remove the old 24-hour trial task, if it is still registered.
    [string]$OldTaskName = 'WeighbridgeAgent-24h',

    # Register without starting. For a machine that is not ready to go live yet.
    [switch]$NoStart
)

$ErrorActionPreference = 'Stop'

$me = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $me.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run this from an elevated PowerShell -- registering a task as SYSTEM needs Administrator."
}

$agent  = Join-Path $Dir 'Start-WeighbridgeAgent.ps1'
$config = Join-Path $Dir 'weighbridge-agent.config.json'
foreach ($f in $agent, $config) {
    if (-not (Test-Path $f)) { throw "Missing $f. Copy the contents of this folder to $Dir first." }
}

$cfg = Get-Content $config -Raw | ConvertFrom-Json
foreach ($p in 'dataverseUrl', 'tenantId', 'clientId', 'clientSecret') {
    $v = [string]$cfg.$p
    if ([string]::IsNullOrWhiteSpace($v) -or $v -like '*REPLACE-ME*') { throw "$p is not set in $config." }
}
Write-Host ("config: {0} terminal(s), settle {1}s, update {2}s" -f `
    @($cfg.terminals).Count, $cfg.settleSeconds, $cfg.updateSteadySeconds) -ForegroundColor DarkGray
Write-Host ("writing to: {0}/{1}" -f $cfg.dataverseUrl.TrimEnd('/'), $cfg.entitySet) -ForegroundColor DarkGray

foreach ($t in @($OldTaskName, $TaskName)) {
    if (Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue) {
        Write-Host "removing existing task $t" -ForegroundColor DarkGray
        Stop-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $t -Confirm:$false
    }
}

$action = New-ScheduledTaskAction -Execute 'powershell.exe' -WorkingDirectory $Dir `
    -Argument "-NoProfile -ExecutionPolicy Bypass -Command `"& '$agent' -ConfigPath '$config' *>> '$Dir\task-console.log'`""

# No -RepetitionDuration: on PowerShell 5.1 [TimeSpan]::MaxValue is rejected, and leaving it out
# is what means "indefinitely".
$atBoot   = New-ScheduledTaskTrigger -AtStartup
$watchdog = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Minutes 10)

$settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable `
    -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) `
    -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger @($atBoot, $watchdog) `
    -Settings $settings -User 'SYSTEM' -RunLevel Highest | Out-Null
Write-Host "registered $TaskName -- starts at boot, restarted within 10 min if it dies" -ForegroundColor Green

if ($NoStart) {
    Write-Host "not started (-NoStart). Start it with: Start-ScheduledTask -TaskName '$TaskName'" -ForegroundColor Yellow
    return
}

Start-ScheduledTask -TaskName $TaskName
Start-Sleep -Seconds 20

$state = (Get-ScheduledTask -TaskName $TaskName).State
$info  = Get-ScheduledTaskInfo -TaskName $TaskName
Write-Host ""
Write-Host ("state {0}, last run {1}, last result {2}" -f $state, $info.LastRunTime, $info.LastTaskResult) `
    -ForegroundColor $(if ("$state" -eq 'Running') { 'Green' } else { 'Red' })

if ("$state" -ne 'Running') {
    Write-Host "It started and stopped. The reason is at the end of $Dir\task-console.log:" -ForegroundColor Yellow
    Get-Content "$Dir\task-console.log" -Tail 15 -ErrorAction SilentlyContinue
    return
}

& (Join-Path $Dir 'Test-WeighbridgeAgent.ps1')
